export const startInstance = undefined
